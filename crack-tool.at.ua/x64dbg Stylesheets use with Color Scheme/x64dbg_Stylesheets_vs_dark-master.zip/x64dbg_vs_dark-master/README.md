# x64dbg_vs_dark
x64dbg stylesheet like visual studio dark theme

More info at x64dbg wiki:
- https://github.com/x64dbg/x64dbg/wiki/Stylesheets
- https://github.com/x64dbg/x64dbg/wiki/Color-Schemes


![x64dbg_vs_dark](http://i.imgur.com/0vdWCvN.png)


Use with [Visual Studio Dark Theme by ThunderCls](https://gist.github.com/ThunderCls/4dcc4b8c1cace8c9cae5612fc696d465) scheme.


**Installation**:

1. Copy style.css and icons folder to the same folder of x64dbg executable

2. Load the configuration of the scheme Visual Studio Dark Theme

3. Open the debugger and everything should be setted up
